# event_subscription_project

This project was part of my final project during my internship in datalab academy.
Analysis was done to help forcast the total events per time of the day among many other analyses and visuals.
Tools used to accomplish this include: Jupyter, PowerBI, mySQL and PowerPoint 
