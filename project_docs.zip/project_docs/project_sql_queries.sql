use datalab_project;
# view all data
SELECT 
    *
FROM
    actions2load ;

/*count all records on the table*/
/* the total records on the action2load table is 65,132*/
SELECT 
    COUNT(*)
FROM
    actions2load;
    
 # Checking unique account_id   
SELECT DISTINCT
   (account_id)
FROM
    actions2load;

#total number of unique account id is 6251
SELECT count(DISTINCT
   (account_id))
FROM
    actions2load;
    

#total number of unique events is 25
SELECT count(DISTINCT
   (event_type))
FROM
    actions2load;
    
    /* number of times events occurred based on different times of the day*/
SELECT 
    DATE_FORMAT(event_time, '%H:%i') AS time_of_the_day,
    COUNT(*) AS event_count
FROM
    actions2load
GROUP BY time_of_the_day
ORDER BY time_of_the_day ;



#Checking events that are most common - by counting which events has the highest occurence
/* ReadingOwnedBook event_type has the highest number of occurrence of 24,628 followed by HighlightCreated event_type with 6078 occurence*/
SELECT 
    event_type, COUNT('event_type') AS event_frequency
FROM
    actions2load
GROUP BY event_type
ORDER BY event_frequency DESC;

#Checking events that are least common - by counting which events has the lowest occurence
/* UnknownOriginLivebookLinkOpened event_type has the lowest number of occurrence of 1 followed by ProductSeeFreeLinkOpened event_type with 12 occurence*/
SELECT 
    event_type, COUNT('event_type') AS event_frequency
FROM
    actions2load
GROUP BY event_type
ORDER BY event_frequency ASC;

#Checking account_id with the highest number of events -
/* Account Id with the highest number of event is caffe2b03e6057845c52212acaaa1a34 (1574 events occurence) */
SELECT 
    account_id, COUNT('account_id') AS event_frequency
FROM
    actions2load
GROUP BY account_id
ORDER BY event_frequency Desc LIMIT 1;

#Checking account_id with the least number of events -
/* Account Id with the least number of event is eb19e0af88f04dd5cd33bc7ae13cb85f (1 events occurence) . */
SELECT 
    account_id, COUNT('account_id') AS event_frequency
FROM
    actions2load
GROUP BY account_id
ORDER BY event_frequency ASC
LIMIT 1;






